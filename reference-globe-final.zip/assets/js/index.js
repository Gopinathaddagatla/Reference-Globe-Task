
'use strict';

const siteHeader = document.getElementById('header');
const siteHeaderHeight = siteHeader.offsetHeight;

window.addEventListener('scroll', () => {
    const top = document.documentElement.scrollTop || document.body.scrollTop;
    if(top > siteHeaderHeight) {
        siteHeader.classList.add('fixed');
    } else {
        siteHeader.classList.remove('fixed');
    }
}, false);

let readmore = document.querySelector('.readmore');

// swiper slider
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    breakpoints: {
        640: {
          slidesPerView: 1,
          spaceBetween: 10,
        },
        991: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        1024: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        1199: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
        1399: {
            slidesPerView: 3,
            spaceBetween: 20,
            // centerMode: true,
            // centerPadding: '80px',
          },
      },
  });